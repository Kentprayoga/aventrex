

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3>Inbox Admin</h3>

    <div class="row">
        
        <div class="col-md-3">
            <h5>Pengguna:</h5>
            <ul class="list-group">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('admin.chat', ['user_id' => $user->id])); ?>">
                            <?php echo e($user->email); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        
        <div class="col-md-9">
            <?php if($selectedUser): ?>
                <h5>Chat dengan: <?php echo e($selectedUser->email); ?></h5>

                <div class="border p-3 mb-3" style="height: 400px; overflow-y: auto;">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 p-3 rounded"
                            style="background-color: <?php echo e($msg->sender_id == auth()->id() ? '#d1e7dd' : '#f8d7da'); ?>; 
                                margin-left: <?php echo e($msg->sender_id == auth()->id() ? 'auto' : '0'); ?>;">
                            <strong><?php echo e($msg->sender_id == auth()->id() ? 'Admin' : $selectedUser->email); ?>:</strong>
                            <p><?php echo e($msg->message); ?></p>
                            <br>
                            <small><?php echo e($msg->created_at->format('d M Y H:i')); ?></small>
                            
                            <?php if($msg->sender_id == auth()->id()): ?> 
                                <form action="<?php echo e(route('admin.chat.delete', ['id' => $msg->id])); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus pesan ini?')">Hapus</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <form method="POST" action="<?php echo e(route('admin.chat', ['user_id' => $selectedUser->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <textarea name="message" class="form-control" rows="3" placeholder="Tulis balasan..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Kirim Balasan</button>
                </form>

                
                <form action="<?php echo e(route('admin.chat.clear', ['userId' => $selectedUser->id])); ?>" method="POST" style="margin-top: 20px;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus semua pesan dengan pengguna ini?')">Hapus Semua Pesan</button>
                </form>
            <?php else: ?>
                <p>Pilih pengguna dari daftar untuk melihat percakapan.</p>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\resources\views/chat/index.blade.php ENDPATH**/ ?>