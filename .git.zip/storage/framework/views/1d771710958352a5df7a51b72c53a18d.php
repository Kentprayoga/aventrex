<h2>History Dokumen</h2>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Nomor Dokumen</th>
            <th>Kategori</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($doc->name); ?></td>
                <td><?php echo e($doc->document_number); ?></td>
                <td><?php echo e($doc->template->category->name); ?></td>
                <td><?php echo e($doc->approval->status ?? 'Belum ada'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\finally\finally\resources\views/history/cetak-history.blade.php ENDPATH**/ ?>