<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Edit Data Karyawan</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('user.update', $profile->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Nama -->
        <div class="mb-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" name="name" value="<?php echo e(old('name', $profile->name)); ?>" class="form-control" required>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" value="<?php echo e(old('email', $profile->user->email)); ?>" class="form-control" required>
        </div>

        <!-- NIP -->
        <div class="mb-3">
            <label for="nip" class="form-label">NIP</label>
            <input type="text" name="nip" value="<?php echo e(old('nip', $profile->nip)); ?>" class="form-control" required>
        </div>

        <!-- No Telepon -->
        <div class="mb-3">
            <label for="phone_number" class="form-label">No Telepon</label>
            <input type="text" name="phone_number" value="<?php echo e(old('phone_number', $profile->phone_number)); ?>" class="form-control" required>
        </div>

        <!-- Tanggal Lahir -->
        <div class="mb-3">
            <label for="tgllahir" class="form-label">Tanggal Lahir</label>
            <input type="date" name="tgllahir" value="<?php echo e(old('tgllahir', $profile->tgllahir)); ?>" class="form-control" required>
        </div>

        <!-- Tanggal Masuk -->
        <div class="mb-3">
            <label for="tglmasuk" class="form-label">Tanggal Masuk</label>
            <input type="date" name="tglmasuk" value="<?php echo e(old('tglmasuk', $profile->tglmasuk)); ?>" class="form-control" required>
        </div>

        <!-- Alamat -->
        <div class="mb-3">
            <label for="address" class="form-label">Alamat</label>
            <textarea name="address" class="form-control" rows="2"><?php echo e(old('address', $profile->address)); ?></textarea>
        </div>

        <!-- Posisi -->
        <div class="mb-3">
            <label for="position_id" class="form-label">Posisi</label>
            <select name="position_id" class="form-control" required>
                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($position->id); ?>" <?php echo e($profile->user->details->first()->position_id == $position->id ? 'selected' : ''); ?>>
                        <?php echo e($position->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Divisi -->
        <div class="mb-3">
            <label for="division_id" class="form-label">Divisi</label>
            <select name="division_id" class="form-control" required>
                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($division->id); ?>"
                        <?php echo e($profile->user->details->first()->workDivisions->first()->division_id == $division->id ? 'selected' : ''); ?>>
                        <?php echo e($division->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Tombol Submit -->
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\resources\views/user/edit.blade.php ENDPATH**/ ?>