


<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .chat-container {
        display: flex;
        flex-direction: row;
        height: 80vh;
        gap: 20px;
    }

    .chat-sidebar {
        width: 30%;
        background-color: #1f2937; /* dark blue-gray */
        border-radius: 10px;
        overflow-y: auto;
        color: white;
    }

    .chat-sidebar a {
        display: block;
        padding: 12px 16px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        text-decoration: none;
        color: white;
    }

    .chat-sidebar a:hover {
        background-color: #374151;
    }

    .chat-sidebar a.active {
        background-color: #3b82f6; /* blue */
    }

    .chat-content {
        flex-grow: 1;
        background-color: #f3f4f6;
        border-radius: 10px;
        display: flex;
        flex-direction: column;
    }

    .chat-message {
        max-width: 60%;
        padding: 10px 15px;
        margin-bottom: 10px;
        border-radius: 20px;
        word-wrap: break-word;
    }

    .chat-admin {
        background-color: #a7f3d0; /* green */
        margin-left: auto;
        border-bottom-right-radius: 0;
    }

    .chat-user {
        background-color: #e5e7eb; /* gray */
        margin-right: auto;
        border-bottom-left-radius: 0;
    }

    .chat-footer textarea {
        resize: none;
    }

    @media (max-width: 768px) {
        .chat-container {
            flex-direction: column;
        }

        .chat-sidebar {
            width: 100%;
        }

        .chat-content {
            display: none;
        }

        .chat-content.active {
            display: flex;
        }

        .chat-sidebar.hidden-mobile {
            display: none;
        }
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="container chat-container">

    
    <div class="chat-sidebar <?php echo e($selectedUser ? 'hidden-mobile' : ''); ?>" id="chatSidebar">
        <div class="p-3 border-bottom" style="background-color: #111827;">
            <h5 style="margin: 0;">📋 Daftar Chat</h5>
        </div>

        
        <div class="p-3">
            <form method="GET" action="<?php echo e(route('admin.chat')); ?>">
                <input type="text" name="search" class="form-control" placeholder="Cari nama..." value="<?php echo e(request('search')); ?>">
            </form>
        </div>

        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('admin.chat', ['user_id' => $user->id])); ?>"
               class="<?php echo e($selectedUser && $selectedUser->id == $user->id ? 'active' : ''); ?>">
                <strong><?php echo e($user->profile->name ?? $user->email); ?></strong>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="chat-content <?php echo e($selectedUser ? 'active' : ''); ?>" id="chatContent">
        <?php if($selectedUser): ?>
            
            <div class="d-block d-md-none p-2 border-bottom bg-white">
                <button class="btn btn-sm btn-outline-secondary" onclick="goBackToSidebar()">← Kembali</button>
            </div>

            
            <div style="padding: 15px; border-bottom: 1px solid #ccc; background-color: white;">
                <h5>Chat dengan: <strong><?php echo e($selectedUser->profile->name ?? $selectedUser->email); ?></strong></h5>
            </div>

            
            <div style="flex-grow: 1; padding: 15px; overflow-y: auto;">
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="chat-message <?php echo e($msg->sender_id == auth()->id() ? 'chat-admin' : 'chat-user'); ?>">
                        <strong><?php echo e($msg->sender_id == auth()->id() ? 'Admin' : $selectedUser->profile->name ?? $selectedUser->email); ?></strong>
                        <p style="margin: 5px 0;"><?php echo e($msg->message); ?></p>
                        <small style="font-size: 0.8rem; color: #555;"><?php echo e($msg->created_at->format('d M Y H:i')); ?></small>

                        <?php if($msg->sender_id == auth()->id()): ?>
                            <form action="<?php echo e(route('admin.chat.delete', ['id' => $msg->id])); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger btn-sm mt-1" onclick="return confirm('Hapus pesan ini?')">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <form method="POST" action="<?php echo e(route('admin.chat', ['user_id' => $selectedUser->id])); ?>" class="chat-footer p-3 border-top bg-white">
                <?php echo csrf_field(); ?>
                <textarea name="message" class="form-control mb-2" rows="2" placeholder="Tulis balasan..." required></textarea>
                <button type="submit" class="btn btn-primary w-100">Kirim Balasan</button>
            </form>

            
            <form action="<?php echo e(route('admin.chat.clear', ['userId' => $selectedUser->id])); ?>" method="POST" class="p-3 bg-white border-top">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-outline-danger w-100" onclick="return confirm('Hapus semua pesan dengan pengguna ini?')">Hapus Semua Pesan</button>
            </form>

        <?php else: ?>
            <div style="flex-grow: 1; display: flex; align-items: center; justify-content: center; color: #777;">
                <p>Pilih pengguna dari daftar untuk melihat percakapan.</p>
            </div>
        <?php endif; ?>
    </div>
</div>


<script>
    function goBackToSidebar() {
        document.getElementById('chatContent').classList.remove('active');
        document.getElementById('chatSidebar').classList.remove('hidden-mobile');
    }

    document.querySelectorAll('.chat-sidebar a').forEach(link => {
        link.addEventListener('click', function () {
            setTimeout(() => {
                document.getElementById('chatContent').classList.add('active');
                document.getElementById('chatSidebar').classList.add('hidden-mobile');
            }, 100);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\finally\resources\views/chat/index.blade.php ENDPATH**/ ?>