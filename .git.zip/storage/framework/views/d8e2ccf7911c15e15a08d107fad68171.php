

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="mb-4">Log Aktivitas Pengguna</h2>

    <!-- Filter -->
    <form method="GET" action="<?php echo e(route('adminlog.index')); ?>" class="mb-4">
        <div class="row g-2 align-items-center">
            <div class="col-auto">
                <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="form-control" />
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary">Filter Tanggal</button>
                <a href="<?php echo e(route('adminlog.index')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 fw-bold text-primary">Riwayat Log (Terbaru)</h4>
        </div>

        <div class="card-body">
            <a href="<?php echo e(route('adminlog.pdf', ['date' => request('date')])); ?>" class="btn btn-danger mb-3">
                Download PDF
            </a>
            <?php
                $perPage = 30;
                $currentPage = request()->get('page', 1);
                $offset = ($currentPage - 1) * $perPage;

                $paginatedLogs = $logs->slice($offset, $perPage)->values();
                $paginator = new Illuminate\Pagination\LengthAwarePaginator(
                    $paginatedLogs,
                    $logs->count(),
                    $perPage,
                    $currentPage,
                    ['path' => request()->url(), 'query' => request()->query()]
                );
            ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pengguna</th>
                            <th>Aksi</th>
                            <th>Detail</th>
                            <th>IP Address</th>
                            <th>User Agent</th>
                            <th>Waktu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $paginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <!-- Penomoran mundur -->
                                <td><?php echo e($logs->count() - ($offset + $index)); ?></td>
                                <td><?php echo e(optional($log->user->profile)->name ?? 'User dihapus'); ?></td>
                                <td><?php echo e($log->action); ?></td>
                                <td><?php echo e($log->detail ?? '-'); ?></td>
                                <td><?php echo e($log->ip_address ?? '-'); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::limit($log->user_agent, 50)); ?></td>
                                <td><?php echo e($log->created_at->format('d-m-Y H:i:s')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Tidak ada data log aktivitas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination manual -->
            <nav>
                <?php echo e($paginator->links('pagination::bootstrap-5')); ?>

            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\finally\resources\views/adminlog/index.blade.php ENDPATH**/ ?>