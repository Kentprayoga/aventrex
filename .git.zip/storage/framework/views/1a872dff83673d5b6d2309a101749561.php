

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1 class="text-dark mb-4">Selamat Datang, Admin!</h1>

    <!-- Kartu Dashboard -->
    <div class="d-flex gap-4 overflow-auto pb-2">
      <a href="<?php echo e(route('history.index')); ?>" class="text-decoration-none">
        <div class="card shadow-sm" style="min-width: 220px;">
          <div class="card-body text-center">
            <h3 class="card-title text-dark"><?php echo e($totalDocuments); ?></h3>
            <p class="card-text fw-semibold text-dark">Total Documents</p>
          </div>
        </div>
      </a>

      <a href="<?php echo e(route('approvals.index')); ?>" class="text-decoration-none">
        <div class="card shadow-sm" style="min-width: 220px;">
          <div class="card-body text-center">
            <h3 class="card-title text-dark"><?php echo e($pendingApprovals); ?></h3>
            <p class="card-text fw-semibold text-dark">Pending Approvals</p>
          </div>
        </div>
      </a>

      <a href="<?php echo e(route('admin.chat')); ?>" class="text-decoration-none">
        <div class="card shadow-sm" style="min-width: 220px;">
          <div class="card-body text-center">
            <h3 class="card-title text-dark"><?php echo e($incomingMessages); ?></h3>
            <p class="card-text fw-semibold text-dark">Pesan Masuk</p>
          </div>
        </div>
      </a>
    </div>

    <!-- Chart Pengajuan per Tanggal -->
    <div class="card mt-4 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Pengajuan per Tanggal (7 Hari Terakhir)</h5>
        <canvas id="documentsChart"></canvas>
      </div>
    </div>

  </div>

  <!-- Script Chart.js -->
  <script>
    var ctx = document.getElementById('documentsChart').getContext('2d');
    var documentsChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?php echo json_encode($dates, 15, 512) ?>, // Tanggal
        datasets: [{
          label: 'Jumlah Pengajuan',
          data: <?php echo json_encode($counts, 15, 512) ?>, // Jumlah pengajuan
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>