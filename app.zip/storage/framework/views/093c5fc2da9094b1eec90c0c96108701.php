<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Log Aktivitas</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 4px; text-align: left; }
    </style>
</head>
<body>
    <h2>Laporan Log Aktivitas Pengguna</h2>

    <?php if($filterDate): ?>
        <p><strong>Filter Tanggal:</strong> <?php echo e(\Carbon\Carbon::parse($filterDate)->format('d-m-Y')); ?></p>
    <?php else: ?>
        <p><strong>Tanggal:</strong> Semua (terbaru maksimal 100)</p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pengguna</th>
                <th>Aksi</th>
                <th>Detail</th>
                <th>IP Address</th>
                <th>User Agent</th>
                <th>Waktu</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e(optional($log->user->profile)->name ?? 'User dihapus'); ?></td>
                    <td><?php echo e($log->action); ?></td>
                    <td><?php echo e($log->detail ?? '-'); ?></td>
                    <td><?php echo e($log->ip_address ?? '-'); ?></td>
                    <td><?php echo e(\Illuminate\Support\Str::limit($log->user_agent, 40)); ?></td>
                    <td><?php echo e($log->created_at->format('d-m-Y H:i:s')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Tidak ada data.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\finally\finally\resources\views/adminlog/pdf.blade.php ENDPATH**/ ?>