

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h1 class="mb-4">Daftar Pengajuan</h1>
            <div class="card-body">

                <!-- Form Filter -->
                <form action="<?php echo e(route('history.index')); ?>" method="get" class="card p-4 mb-4 shadow-sm">
                    <div class="row">
                        <!-- Kategori -->
                        <div class="col-md-3 mb-3">
                            <label for="category_id" class="form-label">Kategori</label>
                            <select name="categorie_id" id="categorie_id" class="form-select">
                                <option value="">-- Pilih Kategori --</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('categorie_id') == $category->id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                        <!-- Status -->
                        <div class="col-md-3 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="">-- Pilih Status --</option>
                                <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>
                        </div>

                        <!-- Tanggal Mulai -->
                        <div class="col-md-3 mb-3">
                            <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
                            <input type="date" name="tanggal_mulai" id="tanggal_mulai" value="<?php echo e(request('tanggal_mulai')); ?>" class="form-control">
                        </div>

                        <!-- Tanggal Selesai -->
                        <div class="col-md-3 mb-3">
                            <label for="tanggal_selesai" class="form-label">Tanggal Selesai</label>
                            <input type="date" name="tanggal_selesai" id="tanggal_selesai" value="<?php echo e(request('tanggal_selesai')); ?>" class="form-control">
                        </div>
                    </div>

                    <!-- Filter Button -->
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>

                <!-- Cetak Semua Dokumen Button -->
                <a href="<?php echo e(route('history.cetak')); ?>" class="btn btn-success mb-4">Cetak Semua Dokumen</a>

                <!-- Tabel Dokumen -->
                <div class="table-responsive">
                    <?php if($documents->isEmpty()): ?>
                        <p class="text-center">Tidak ada data yang ditemukan.</p>
                    <?php else: ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Nomor Dokumen</th>
                                    <th>Kategori</th>
                                    <th>Status</th>
                                    <th>File</th> 
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($doc->name); ?></td>
                                        <td><?php echo e($doc->document_number); ?></td>
                                        <td><?php echo e($doc->template->category->name ?? 'Kategori tidak tersedia'); ?></td>
                                        <td><?php echo e($doc->approval->status ?? 'Belum ada'); ?></td>
                                        <td>
                                            <?php if($doc->template->file_path): ?>
                                                <a href="<?php echo e(asset('storage/' . $doc->template->file_path)); ?>" target="_blank">Lihat File</a>
                                            <?php else: ?>
                                                <span class="text-muted">Tidak ada file</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('history.cetak.satu', $doc->id)); ?>" class="btn btn-info btn-sm">Cetak</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>        
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\finally\resources\views/history/index.blade.php ENDPATH**/ ?>