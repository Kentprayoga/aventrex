<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
    <h2>Halaman Approval Dokumen</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>nip</th>
                            <th>Nama Surat</th>
                            <th>Nama Pengaju</th>
                            <th>Nomor Dokumen</th>
                            <th>Tanggal Pengajuan</th> <!-- Menampilkan tanggal pengajuan -->
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($approval->document->user->profile->nip); ?></td>
                                <td><?php echo e($approval->document->template->name ?? '-'); ?></td>
                                <td><?php echo e($approval->document->user->profile->name); ?></td> <!-- Nama Pengaju -->
                                <td><?php echo e($approval->document->document_number); ?></td> <!-- Nomor Dokumen -->
                                <td><?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i:s')); ?></td> <!-- Tanggal Pengajuan oleh user -->
                                <td>
                                    <span class="badge bg-info text-dark">
                                        <?php echo e($approval->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#documentModal<?php echo e($approval->id); ?>">
                                        Lihat
                                    </button>
                                </td>
                            </tr>

                            <!-- Modal untuk melihat detail dokumen -->
                            <div class="modal fade" id="documentModal<?php echo e($approval->id); ?>" tabindex="-1" aria-labelledby="documentModalLabel<?php echo e($approval->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="documentModalLabel<?php echo e($approval->id); ?>">Detail Dokumen</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p><strong>ID Pengaju:</strong> <?php echo e($approval->document->user_id); ?></p>
                                            <p><strong>Nama Pengaju:</strong> <?php echo e($approval->document->user->profile->name); ?></p> <!-- Nama Pengaju -->
                                            <p><strong>Nomor Dokumen:</strong> <?php echo e($approval->document->document_number); ?></p>
                                            <p><strong>Tanggal Pengajuan:</strong> <?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i:s')); ?></p> <!-- Tanggal Pengajuan -->
                                            <p><strong>Alasan:</strong> <?php echo e($approval->document->alasan ?? '-'); ?></p>

                                            <?php if($approval->document->file_path): ?>
                                                <p><strong>File Dokumen:</strong></p>
                                                <a href="<?php echo e(asset('storage/' . $approval->document->file_path)); ?>" target="_blank" class="btn btn-secondary">Lihat / Unduh File</a>
                                            <?php else: ?>
                                                <p><strong>Data Form:</strong></p>
                                                <ul>
                                                    <li><strong>Nama:</strong> <?php echo e($approval->document->name); ?></li>
                                                    <li><strong>Nomor Dokumen:</strong> <?php echo e($approval->document->document_number); ?></li>
                                                </ul>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <form action="<?php echo e(route('approvals.approve', $approval->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success">Setujui</button>
                                            </form>

                                            <form action="<?php echo e(route('approvals.reject', $approval->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">Tolak</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Tidak ada pengajuan yang menunggu approval.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\resources\views/approvals/index.blade.php ENDPATH**/ ?>