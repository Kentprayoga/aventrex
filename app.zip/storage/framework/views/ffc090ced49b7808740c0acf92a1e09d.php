<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h2 class="mb-4 fw-bold">📝 Halaman Approval Dokumen</h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <div class="card shadow-sm mb-5">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">📅 Pengajuan Cuti Tahunan</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered align-middle text-center">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>NIP</th>
                        <th>Nama Surat</th>
                        <th>Nama Pengaju</th>
                        <th>Nomor Dokumen</th>
                        <th>Tanggal Pengajuan</th>
                        <th>Sisa Cuti</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cutiTahunanApprovals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($approval->document->user->profile->nip); ?></td>
                            <td><?php echo e($approval->document->template->name ?? '-'); ?></td>
                            <td><?php echo e($approval->document->user->profile->name); ?></td>
                            <td><?php echo e($approval->document->document_number); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i')); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($approval->document->user->leaveBalance->remaining_leave ?? '0'); ?> hari</span></td>
                            <td>
                                <span class="badge bg-warning text-dark text-uppercase"><?php echo e($approval->status); ?></span>
                            </td>
                            <td>
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalCuti<?php echo e($approval->id); ?>">
                                    <i class="bi bi-eye"></i> Detail
                                </button>
                            </td>
                        </tr>

                        
                        <div class="modal fade" id="modalCuti<?php echo e($approval->id); ?>" tabindex="-1" aria-labelledby="modalLabelCuti<?php echo e($approval->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable">
                                <div class="modal-content">
                                    <div class="modal-header bg-light">
                                        <h5 class="modal-title">🗂 Detail Pengajuan Cuti</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                    </div>
                                    <div class="modal-body text-start">
                                        <p><strong>Nama Pengaju:</strong> <?php echo e($approval->document->user->profile->name); ?></p>
                                        <p><strong>NIP:</strong> <?php echo e($approval->document->user->profile->nip); ?></p>
                                        <p><strong>Nomor Dokumen:</strong> <?php echo e($approval->document->document_number); ?></p>
                                        <p><strong>Tanggal Pengajuan:</strong> <?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i')); ?></p>
                                        <p><strong>Sisa Cuti:</strong> <?php echo e($approval->document->user->leaveBalance->remaining_leave ?? '0'); ?> hari</p>
                                        <p><strong>Alasan:</strong> <?php echo e($approval->document->alasan ?? '-'); ?></p>
                                        
                                        <?php if($approval->document->file_path): ?>
                                            <p><strong>Preview File Dokumen:</strong></p>
                                            <div class="ratio ratio-4x3">
                                                <iframe src="<?php echo e(asset('storage/' . $approval->document->file_path)); ?>" allowfullscreen></iframe>
                                            </div>

                                            <p class="mt-2">
                                                <a href="<?php echo e(asset('storage/' . $approval->document->file_path)); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                                                    <i class="bi bi-download"></i> Unduh PDF
                                                </a>
                                            </p>
                                        <?php endif; ?>

                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <form action="<?php echo e(route('approvals.approve', $approval->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success">
                                                <i class="bi bi-check-circle"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('approvals.reject', $approval->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group mb-2">
                                                <label for="alasan_<?php echo e($approval->id); ?>" class="form-label">Alasan Penolakan</label>
                                                <textarea name="alasan" id="alasan_<?php echo e($approval->id); ?>" class="form-control" rows="2" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-danger">
                                                <i class="bi bi-x-circle"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-muted text-center">Tidak ada pengajuan cuti tahunan yang menunggu approval.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="card shadow-sm">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0">📁 Pengajuan Lainnya</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered align-middle text-center">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>NIP</th>
                        <th>Nama Surat</th>
                        <th>Nama Pengaju</th>
                        <th>Nomor Dokumen</th>
                        <th>Tanggal Pengajuan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $otherApprovals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $approval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($approval->document->user->profile->nip); ?></td>
                            <td><?php echo e($approval->document->template->name ?? '-'); ?></td>
                            <td><?php echo e($approval->document->user->profile->name); ?></td>
                            <td><?php echo e($approval->document->document_number); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i')); ?></td>
                            <td><span class="badge bg-warning text-dark text-uppercase"><?php echo e($approval->status); ?></span></td>
                            <td>
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalOther<?php echo e($approval->id); ?>">
                                    <i class="bi bi-eye"></i> Detail
                                </button>
                            </td>
                        </tr>

                        
                        <div class="modal fade" id="modalOther<?php echo e($approval->id); ?>" tabindex="-1" aria-labelledby="modalLabelOther<?php echo e($approval->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable">
                                <div class="modal-content">
                                    <div class="modal-header bg-light">
                                        <h5 class="modal-title">🗂 Detail Pengajuan</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                    </div>
                                    <div class="modal-body text-start">
                                        <p><strong>Nama Pengaju:</strong> <?php echo e($approval->document->user->profile->name); ?></p>
                                        <p><strong>NIP:</strong> <?php echo e($approval->document->user->profile->nip); ?></p>
                                        <p><strong>Nomor Dokumen:</strong> <?php echo e($approval->document->document_number); ?></p>
                                        <p><strong>Tanggal Pengajuan:</strong> <?php echo e(\Carbon\Carbon::parse($approval->document->tanggal_pengajuan)->format('d-m-Y H:i')); ?></p>
                                        <p><strong>Alasan:</strong> <?php echo e($approval->document->alasan ?? '-'); ?></p>

                                        <?php if($approval->document->file_path): ?>
                                            <p><strong>Preview File Dokumen:</strong></p>
                                            <div class="ratio ratio-4x3">
                                                <iframe src="<?php echo e(asset('storage/' . $approval->document->file_path)); ?>" allowfullscreen></iframe>
                                            </div>
                                            <p class="mt-2">
                                                <a href="<?php echo e(asset('storage/' . $approval->document->file_path)); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                                                    <i class="bi bi-download"></i> Unduh PDF
                                                </a>
                                            </p>
                                        <?php endif; ?>

                                    </div>
                                    <div class="modal-footer justify-content-between">
                                        <form action="<?php echo e(route('approvals.approve', $approval->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success">
                                                <i class="bi bi-check-circle"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('approvals.reject', $approval->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group mb-2">
                                                <label for="alasan_<?php echo e($approval->id); ?>" class="form-label">Alasan Penolakan</label>
                                                <textarea name="alasan" id="alasan_<?php echo e($approval->id); ?>" class="form-control" rows="2" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-danger">
                                                <i class="bi bi-x-circle"></i> Tolak
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-muted text-center">Tidak ada pengajuan lainnya yang menunggu approval.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\finally\resources\views/approvals/index.blade.php ENDPATH**/ ?>