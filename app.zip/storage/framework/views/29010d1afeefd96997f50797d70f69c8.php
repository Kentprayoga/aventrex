<h2>Detail Dokumen</h2>
<table border="1" cellpadding="5" cellspacing="0" width="100%">
    <tr>
        <th>Nama</th>
        <td><?php echo e($document->name); ?></td>
    </tr>
    <tr>
        <th>Nomor Dokumen</th>
        <td><?php echo e($document->document_number); ?></td>
    </tr>
    <tr>
        <th>Kategori</th>
        <td><?php echo e($document->template->category->name); ?></td>
    </tr>
    <tr>
        <th>Template</th>
        <td><?php echo e($document->template->name); ?></td>
    </tr>
    <tr>
        <th>Tanggal Pengajuan</th>
        <td><?php echo e($document->tanggal_pengajuan); ?></td>
    </tr>
    <tr>
        <th>Status</th>
        <td><?php echo e($document->approval->status ?? 'Belum ada'); ?></td>
    </tr>
    <tr>
        <th>Alasan</th>
        <td><?php echo e($document->alasan); ?></td>
    </tr>
</table>
<?php /**PATH C:\laragon\www\finally\finally\resources\views/history/cetak-satu.blade.php ENDPATH**/ ?>