<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow">
        <div class="card-header">
            <h4>Edit Template</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('template.update', $template->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label>Kategori</label>
                    <select name="categorie_id" class="form-control" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $template->categorie_id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Nama Template</label>
                    <input type="text" name="name" value="<?php echo e($template->name); ?>" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Ganti File Template (Opsional)</label>
                    <input type="file" name="file_path" class="form-control">
                    <small>File saat ini: <a href="<?php echo e(asset('storage/' . $template->file_path)); ?>" target="_blank">Lihat File</a></small>
                </div>

                <button type="submit" class="btn btn-primary">Perbarui</button>
                <a href="<?php echo e(route('template.index')); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\finally\finally\resources\views/template/edit.blade.php ENDPATH**/ ?>