<style>
.bg-custom {
    background-color: #1f1770 !important;
}

    </style>

<nav class="navbar navbar-expand navbar-light bg-custom topbar mb-4 static-top shadow">


    <!-- Topbar Search -->


    <!-- Topbar Navbar -->
    

</nav><?php /**PATH C:\laragon\www\finally\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>