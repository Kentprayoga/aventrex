<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\Detail;
use App\Models\Position;
use App\Models\WorkDivision;
use App\Models\Division;
use App\Models\Profile;
use App\Models\Approval;
use App\Models\Log;
use App\Models\Template;
use App\Models\LeaveBalance;
use App\Models\User;
use PhpOffice\PhpWord\IOFactory;
use Dompdf\Dompdf;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use PhpOffice\PhpWord\TemplateProcessor;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Request as GlobalRequest; 

class DocumentController extends Controller
{
    // public function store(Request $request)
    // {
    //     // $data = $request->all();
    //     // if (isset($data['lama_hari']) && $data['lama_hari'] === '') {
    //     //     $data['lama_hari'] = null;
    //     // }
        
    //     // Validasi input
    //     $validator = Validator::make($request->all(), [
    //         'template_id' => 'required|exists:templates,id',
    //         'lama_hari' => 'nullable|integer|max:10',
    //         'alasan' => 'required|string',
    //         'tanggal_diajukan' => 'required|date',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => false,
    //             'errors' => $validator->errors(),
    //         ], 422);
    //     }

    //     $user = Auth::user();

    //     // Ambil template
    //     $template = Template::findOrFail($request->template_id);

    //     $year = now()->year;

    //     // Hitung nomor urut surat berdasarkan template dan tahun
    //     $count = Document::where('template_id', $template->id)
    //         ->whereYear('tanggal_pengajuan', $year)
    //         ->count();

    //     $newNumber = str_pad($count + 1, 4, '0', STR_PAD_LEFT);
    //     $documentNumber = $template->format_nomor . '/' . $newNumber;

    //     // Simpan data dokumen ke DB dulu tanpa file_path
    //     $document = Document::create([
    //         'user_id' => $user->id,
    //         'template_id' => $template->id,
    //         'document_number' => $documentNumber,
    //         'lama_hari' => $request->lama_hari,
    //         'alasan' => $request->alasan,
    //         'tanggal_pengajuan' => now(),
    //         'tanggal_diajukan' => $request->tanggal_diajukan,
    //         'file_path' => null,
    //     ]);

    //     // Path template file di storage
    //     $templateFilePath = storage_path('app/public/' . $template->file_path);

    //     if (!file_exists($templateFilePath)) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => 'File template tidak ditemukan di server',
    //         ], 404);
    //     }

    //     try {
    //         $profile = $user->profile;
    //         $detail = $user->detail; // pastikan relasi sudah dibuat di model User

    //         $positionName = $detail && $detail->position ? $detail->position->name : '-';
    //         $workDivision = $detail ? $detail->workDivision : null;
    //         $divisionName = $workDivision && $workDivision->division ? $workDivision->division->name : '-';

    //         $name = $profile->name ?? '-';
    //         $nip = $profile->nip ?? '-';
    //         $gender = $profile->gender ?? '-';
    //         // Load template DOCX
    //         $templateProcessor = new TemplateProcessor($templateFilePath);

    //         // Isi placeholder sesuai nama placeholder di template DOCX
    //     $templateProcessor->setValue('name', $name);
    //     $templateProcessor->setValue('nip', $nip);
    //     $templateProcessor->setValue('gender', $gender);
    //     $templateProcessor->setValue('lama_hari', $request->lama_hari ?? '-');
    //     $templateProcessor->setValue('alasan', $request->alasan);
    //     $templateProcessor->setValue('tanggal_pengajuan', now()->format('d-m-Y'));
    //     $templateProcessor->setValue('tanggal_diajukan', date('d-m-Y', strtotime($request->tanggal_diajukan)));
    //     $templateProcessor->setValue('document_number', $documentNumber);
    //     $templateProcessor->setValue('user_position', $positionName);
    //     $templateProcessor->setValue('user_division', $divisionName);
    //         // Simpan file hasil generate ke folder public storage documents/
    //         $filename = 'surat_' . $document->id . '_' . time() . '.docx';
    //         $savePath = storage_path('app/public/documents/' . $filename);

    //         // Buat folder documents jika belum ada
    //         if (!file_exists(storage_path('app/public/documents'))) {
    //             mkdir(storage_path('app/public/documents'), 0755, true);
    //         }

    //         $templateProcessor->saveAs($savePath);

    //         // Update file_path di database
    //         $document->file_path = 'documents/' . $filename;
    //         $document->save();

    //         // Simpan approval dengan status pending
    //         Approval::create([
    //             'document_id' => $document->id,
    //             'user_id' => $user->id,
    //             'status' => 'pending',
    //         ]);

    //         Log::create([
    //             'user_id'    => $user->id,
    //             'action'     => 'Pengajuan Dokumen',
    //             'detail'     => 'pengajuan' . ' '.$document->id . ' '.$document->template->category->name .' telah diajukan dan surat digenerate',
    //             'ip_address' => $request->ip(),
    //             'user_agent' => $request->userAgent(),
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Gagal generate surat: ' . $e->getMessage(),
    //         ], 500);
    //     }

    //     return response()->json([
    //         'status' => true,
    //         'message' => 'Pengajuan dokumen berhasil dan surat telah digenerate',
    //         'data' => $document,
    //     ]);
    // }



//     public function store(Request $request)
// {
//     $validator = Validator::make($request->all(), [
//         'template_id' => 'required|exists:templates,id',
//         'lama_hari' => 'nullable|integer|max:10',
//         'alasan' => 'required|string',
//         'tanggal_diajukan' => 'required|date',
//     ]);

//     if ($validator->fails()) {
//         return response()->json([
//             'status' => false,
//             'errors' => $validator->errors(),
//         ], 422);
//     }

//     $user = Auth::user();
//     $template = Template::findOrFail($request->template_id);
//     $year = now()->year;

//     $count = Document::where('template_id', $template->id)
//         ->whereYear('tanggal_pengajuan', $year)
//         ->count();

//     $newNumber = str_pad($count + 1, 4, '0', STR_PAD_LEFT);
//     $documentNumber = $template->format_nomor . '/' . $newNumber;

//     $document = Document::create([
//         'user_id' => $user->id,
//         'template_id' => $template->id,
//         'document_number' => $documentNumber,
//         'lama_hari' => $request->lama_hari,
//         'alasan' => $request->alasan,
//         'tanggal_pengajuan' => now(),
//         'tanggal_diajukan' => $request->tanggal_diajukan,
//         'file_path' => null,
//     ]);

//     $templateFilePath = storage_path('app/public/' . $template->file_path);

//     if (!file_exists($templateFilePath)) {
//         return response()->json([
//             'status' => false,
//             'message' => 'File template tidak ditemukan di server',
//         ], 404);
//     }

//     try {
//         $profile = $user->profile;
//         $detail = $user->detail;

//         $positionName = $detail && $detail->position ? $detail->position->name : '-';
//         $workDivision = $detail ? $detail->workDivision : null;
//         $divisionName = $workDivision && $workDivision->division ? $workDivision->division->name : '-';

//         $name = $profile->name ?? '-';
//         $nip = $profile->nip ?? '-';
//         $gender = $profile->gender ?? '-';

//         // === 1. Generate .docx ===
//         $templateProcessor = new TemplateProcessor($templateFilePath);
//         $templateProcessor->setValue('name', $name);
//         $templateProcessor->setValue('nip', $nip);
//         $templateProcessor->setValue('gender', $gender);
//         $templateProcessor->setValue('lama_hari', $request->lama_hari ?? '-');
//         $templateProcessor->setValue('alasan', $request->alasan);
//         $templateProcessor->setValue('tanggal_pengajuan', now()->format('d-m-Y'));
//         $templateProcessor->setValue('tanggal_diajukan', date('d-m-Y', strtotime($request->tanggal_diajukan)));
//         $templateProcessor->setValue('document_number', $documentNumber);
//         $templateProcessor->setValue('user_position', $positionName);
//         $templateProcessor->setValue('user_division', $divisionName);

//         $filenameDocx = 'surat_' . $document->id . '_' . time() . '.docx';
//         $savePathDocx = storage_path('app/public/documents/' . $filenameDocx);
//         if (!file_exists(dirname($savePathDocx))) {
//             mkdir(dirname($savePathDocx), 0755, true);
//         }
//         $templateProcessor->saveAs($savePathDocx);

//         // === 2. Konversi ke PDF ===
//         $phpWord = IOFactory::load($savePathDocx);
//         $htmlPath = storage_path('app/public/documents/temp_' . time() . '.html');
//         IOFactory::createWriter($phpWord, 'HTML')->save($htmlPath);

//         $dompdf = new Dompdf();
//         $dompdf->loadHtml(file_get_contents($htmlPath));
//         $dompdf->setPaper('A4', 'portrait');
//         $dompdf->render();

//         $filenamePdf = 'surat_' . $document->id . '_' . time() . '.pdf';
//         $savePathPdf = storage_path('app/public/documents/' . $filenamePdf);
//         file_put_contents($savePathPdf, $dompdf->output());

//         // Simpan path PDF ke database
//         $document->file_path = 'documents/' . $filenamePdf;
//         $document->save();

//         // Bersihkan file sementara
//         @unlink($savePathDocx);
//         @unlink($htmlPath);

//         // Simpan approval
//         Approval::create([
//             'document_id' => $document->id,
//             'user_id' => $user->id,
//             'status' => 'pending',
//         ]);

//         // Simpan log
//         Log::create([
//             'user_id'    => $user->id,
//             'action'     => 'Pengajuan Dokumen',
//             'detail'     => 'pengajuan ' . $document->id . ' ' . $document->template->category->name . ' telah diajukan dan surat digenerate',
//             'ip_address' => $request->ip(),
//             'user_agent' => $request->userAgent(),
//         ]);

//         return response()->json([
//             'status' => true,
//             'message' => 'Pengajuan dokumen berhasil dan surat PDF telah digenerate',
//             'data' => $document,
//         ]);
//     } catch (\Exception $e) {
//         return response()->json([
//             'status' => false,
//             'message' => 'Gagal generate surat: ' . $e->getMessage(),
//         ], 500);
//     }
// }


public function store(Request $request)
{
    $validator = Validator::make($request->all(), [
        'template_id' => 'required|exists:templates,id',
        'lama_hari' => 'nullable|integer|max:10',
        'alasan' => 'required|string',
        'tanggal_diajukan' => 'required|date',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'errors' => $validator->errors(),
        ], 422);
    }

    $user = Auth::user();
    $template = Template::with('category')->findOrFail($request->template_id);
    $year = now()->year;

    $count = Document::where('template_id', $template->id)
        ->whereYear('tanggal_pengajuan', $year)
        ->count();

    $newNumber = str_pad($count + 1, 4, '0', STR_PAD_LEFT);
    $documentNumber = $template->format_nomor . '/' . $newNumber;

    $document = Document::create([
        'user_id' => $user->id,
        'template_id' => $template->id,
        'document_number' => $documentNumber,
        'lama_hari' => $request->lama_hari,
        'alasan' => $request->alasan,
        'tanggal_pengajuan' => now(),
        'tanggal_diajukan' => $request->tanggal_diajukan,
        'file_path' => null,
    ]);

    $templateFilePath = storage_path('app/public/' . $template->file_path);

    if (!file_exists($templateFilePath)) {
        return response()->json([
            'status' => false,
            'message' => 'File template tidak ditemukan di server',
        ], 404);
    }

    try {
        $profile = $user->profile;
        $detail  = Detail::where('user_id', $user->id)->first();

        $positionName = '-';
        $divisionName = '-';

        if ($detail) {
            $position = Position::find($detail->position_id);
            $positionName = $position?->name ?? '-';

            $workDivision = WorkDivision::where('detail_id', $detail->id)->first();
            if ($workDivision) {
                $division = Division::find($workDivision->division_id);
                $divisionName = $division?->name ?? '-';
            }
        }


        $name = $profile->name ?? '-';
        $nip = $profile->nip ?? '-';
        $gender = $profile->gender ?? '-';

        // === 1. Generate .docx ===
        $templateProcessor = new TemplateProcessor($templateFilePath);
        $templateProcessor->setValue('name', $name);
        $templateProcessor->setValue('nip', $nip);
        $templateProcessor->setValue('gender', $gender);
        $templateProcessor->setValue('lama_hari', $request->lama_hari ?? '-');
        $templateProcessor->setValue('alasan', $request->alasan);
        $templateProcessor->setValue('tanggal_pengajuan', now()->format('d-m-Y'));
        $templateProcessor->setValue('tanggal_diajukan', date('d-m-Y', strtotime($request->tanggal_diajukan)));
        $templateProcessor->setValue('document_number', $documentNumber);
        $templateProcessor->setValue('user_position', $positionName);
        $templateProcessor->setValue('user_division', $divisionName);

        $timestamp = time();
        $filenameDocx = 'surat_' . $document->id . '_' . $timestamp . '.docx';
        $savePathDocx = storage_path('app/public/documents/' . $filenameDocx);
        if (!file_exists(dirname($savePathDocx))) {
            mkdir(dirname($savePathDocx), 0755, true);
        }
        $templateProcessor->saveAs($savePathDocx);

        // === 2. Konversi ke PDF ===
        $phpWord = IOFactory::load($savePathDocx);
        $htmlPath = storage_path('app/public/documents/temp_' . $timestamp . '.html');
        IOFactory::createWriter($phpWord, 'HTML')->save($htmlPath);

        $dompdf = new Dompdf();
        $dompdf->loadHtml(file_get_contents($htmlPath));
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        $filenamePdf = 'surat_' . $document->id . '_' . $timestamp . '.pdf';
        $savePathPdf = storage_path('app/public/documents/' . $filenamePdf);
        file_put_contents($savePathPdf, $dompdf->output());

        $document->file_path = 'documents/' . $filenamePdf;
        $document->save();

        @unlink($savePathDocx);
        @unlink($htmlPath);

        Approval::create([
            'document_id' => $document->id,
            'user_id' => $user->id,
            'status' => 'pending',
        ]);

        Log::create([
            'user_id'    => $user->id,
            'action'     => 'Pengajuan Dokumen',
            'detail' => 'Pengajuan dengan nomor ' . $documentNumber .
                        ' (' . optional($template->category)->name . ') telah diajukan dan surat digenerate',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Pengajuan dokumen berhasil dan surat PDF telah digenerate',
            'data' => $document,
        ], 202);
    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => 'Gagal generate surat',
            'error' => $e->getMessage(),
        ], 500);
    }
}


    
    
 
}